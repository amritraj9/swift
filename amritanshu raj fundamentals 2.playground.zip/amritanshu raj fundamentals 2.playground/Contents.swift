import UIKit

var greeting = "Hello, playground i am amritanshu raj"

print(greeting)

var hello="msrit mac lab"
print(hello)
var new="today i am going to learn new language "
print(new)
var myname="amrit"
let yourname=myname
myname="raj"
print(myname)
var msg="this is int "
var msg1="this is float"
let num1=100
var num2=98585785.88999
print(msg,num1)
var window = "installed"
if window == "installed"{
    print("installed")
}
