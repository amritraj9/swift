import UIKit

var greeting = "boolean expression"
print(greeting)
let char:Character="❤️‍🔥"
print(char)
let password="msrit"
if password.count<8{
    print(password.count)
    print("password is less than 8")
}
else{
    print("good password")
    
}
let anotherString:String="msrit ece"
anotherString.hasPrefix("msrit")//checks first string till space
anotherString.hasSuffix("ise")//checks string after space
anotherString.contains("cit")//check if string contains that line
anotherString.uppercased()//just make whole string capital
print(anotherString.uppercased())
let multilinestring="""
how are you?
ans:fine
"""
print(multilinestring)
let name:String="amrit"
let age:Int=19
let concatentedstring=name + "is of" + String(age) + "years old"
print(concatentedstring)
//string interpolation
let interpolation = " \(name) is of \(age) years old"
print(interpolation)
let num1=10
let num2=20
print("sum of \(num1) and \(num2)is  \(num1+num2)")
var year:Int? = nil
 year=2022
let yop=year
print(yop)
print(yop!)//it will not print optional 






